#!/usr/bin/sh
mkdir "ИСТ-922_Юрченко"
cd ИСТ-922_Юрченко
echo "Юрченко Павел Вячеславович 22.12.2000 г.Байконур" > 1.txt
iconv -f UTF-8 -t CP1251 1.txt -o 2.txt
iconv -f UTF-8 -t CP866 1.txt -o 3.txt
iconv -f UTF-8 -t 8859_5 1.txt -o 4.txt
cat 1.txt 2.txt 3.txt 4.txt > 5.txt
zip -9 1.zip 1.txt
zip -9 2.zip 2.txt
zip -9 3.zip 3.txt
zip -9 4.zip 4.txt
zip -9 5.zip 5.txt
bzip2 -k9 1.txt
bzip2 -k9 2.txt
bzip2 -k9 3.txt
bzip2 -k9 4.txt
bzip2 -k9 5.txt
tar cvf - 1.txt | gzip -k9 > 1.tar.gz
tar cvf - 2.txt | gzip -k9 > 2.tar.gz
tar cvf - 3.txt | gzip -k9 > 3.tar.gz
tar cvf - 4.txt | gzip -k9 > 4.tar.gz
tar cvf - 5.txt | gzip -k9 > 5.tar.gz
arj a -ejm 1.arj 1.txt
arj a -ejm 2.arj 2.txt
arj a -ejm 3.arj 3.txt
arj a -ejm 4.arj 4.txt
arj a -ejm 5.arj 5.txt
cd ..
tar cvf - ИСТ-922_Юрченко | bzip2 -k9 > ИСТ-922_Юрченко.tar.bz2
ls -la
rm -r ИСТ-922_Юрченко
