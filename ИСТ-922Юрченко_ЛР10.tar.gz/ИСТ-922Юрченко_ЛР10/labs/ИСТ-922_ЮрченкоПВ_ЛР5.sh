#!/usr/bin/sh
mkdir "ИСТ-922_Юрченко"
cd ИСТ-922_Юрченко
for (( i = 0; i < 100; i++))
do
echo "ИСТ-922 Юрченко Павел Вячеславович 22.12.2000 г.Байконур Yurchenko Pavel Vyacheslavovich Baykonur" >> 1.txt
done
for (( i = 0; i < 50; i++))
do
echo "ИСТ-922 Юрченко Павел Вячеславович 22.12.2000 г.Байконур Yurchenko Pavel Vyacheslavovich Baykonur" | tr [:lower:] [:upper:] >> 1.txt
done
sed -i 'y/abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ/аьсдефгнижклмпорягстцвшхузАВСДЕФГНИЖКЛМИОРОЯСТЦВШХУЗ/' 1.txt
iconv -f UTF-8 -t CP1251 1.txt -o 2.txt
iconv -f UTF-8 -t CP866 1.txt -o 3.txt
iconv -f UTF-8 -t 8859_5 1.txt -o 4.txt
cat 1.txt 2.txt 3.txt 4.txt > 5.txt
for (( i = 1; i <= 5; i++ ))
do
zip -9 $i.zip $i.txt
bzip2 -k9 $i.txt
tar cvf - $i.txt | gzip -k9 > $i.tar.gz
arj a -ejm $i.arj $i.txt
done
cd ..
tar cvf - ИСТ-922_Юрченко | bzip2 -k9 > ИСТ-922_Юрченко.tar.bz2
ls -la
rm -r ИСТ-922_Юрченко

