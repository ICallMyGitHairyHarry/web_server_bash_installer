#!/bin/bash
cd photo_im/photo_archive
convert -strip -resize 480 0.jpg ../photo/0.jpg
for i in {1..50}
do
if ((i%2==0))
then
convert -strip -quality 85% -resize 2304 $i.jpg ../photo/$i.jpg
else
convert -strip -quality 85% -resize 2304 $i.jpg ../photo/$i.jpg &
fi
done
cd ../../
