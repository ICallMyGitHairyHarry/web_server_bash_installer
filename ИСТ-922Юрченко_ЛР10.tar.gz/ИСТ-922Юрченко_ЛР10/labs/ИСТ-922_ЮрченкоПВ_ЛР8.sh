#!/bin/bash
for i in vanna beregite.vodu bolvanka o.ljubvi 80.sportivnaja.gimnastika 80.sportivnaja.hodba 80.tjazhelaja.atletika 80.hokkej.na.trave 80.basketbol avtobus
do
wget http://multiki.arjlover.net/multiki/$i.avi
ffmpeg -i $i.avi -c:v libvpx-vp9 -b:a 128k -b:v 500k -c:a libopus videoIm/$i.webm
done
